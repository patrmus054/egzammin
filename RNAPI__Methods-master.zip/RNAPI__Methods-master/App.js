import React from 'react';

import ApiContainer from './App/Screens/ApiContainer';

const App = () => {
  return (
    <>
      <ApiContainer />
    </>
  );
};


export default App;
