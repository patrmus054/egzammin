# RNAPI__Methods
In this project, we will learn different methods for API calls including fetch() method and Axios method provided by react-native. We will also see the different configurations and properties of these methods using fetch and axios in react native applications.
